package cn.dpocket.moplusand.uinew.ui.view;

/**
 * Created by Apple on 16/7/13.
 */
public class FavoritesFragment extends ViewPagerFragment {

}