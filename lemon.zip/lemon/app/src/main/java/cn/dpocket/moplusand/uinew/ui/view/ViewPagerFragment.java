package cn.dpocket.moplusand.uinew.ui.view;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import cn.dpocket.moplusand.uinew.R;

/**
 * Created by Apple on 16/7/13.
 */
public class ViewPagerFragment extends Fragment {

    private int mPage;
    private ListView mListView;

    private ArrayAdapter mAdapter;

    public static ViewPagerFragment create(int page) {
        ViewPagerFragment fragment = new ViewPagerFragment();
        fragment.mPage = page;
        return fragment;
    }

//    @Override
//    protected View createView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        return null;
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_view_pager, null);
        mListView = (ListView) view.findViewById(R.id.view_pager_list_view);

        View headerView = inflater.inflate(R.layout.view_pager_fragment_list_view_header, null);
        TextView mHeaderTextView = (TextView) headerView.findViewById(R.id.view_pager_fragment_list_view_header_title);
        mHeaderTextView.setBackgroundColor(0xff4d90fe * mPage / 30);
        mHeaderTextView.setText("Page: " + mPage);

        mListView.addHeaderView(headerView);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0) {
//                    JsonData js = mAdapter.getItem(position);
//                    final String url = js!=null?js.optString("pic"):null;
//                    if (!TextUtils.isEmpty(url)) {
//                        getContext().pushFragmentToBackStack(MaterialStyleFragment.class, url);
//                    }
                }
            }
        });

        UserAdapter adapter = new UserAdapter(getActivity().getApplicationContext(), R.layout.simplelist);
        adapter.add(new User(10, "小智", "男"));
        adapter.add(new User(10, "小霞", "女"));
        mListView.setAdapter(adapter);

        return view;
    }

//    public void update(JsonData data) {
//        mAdapter.getDataList().clear();
//        mAdapter.getDataList().addAll(data.optJson("data").optJson("list").toArrayList());
//        mAdapter.notifyDataSetChanged();
//    }

    public void show() {

    }

    public void hide() {

    }

    public boolean checkCanDoRefresh() {
        if (mAdapter.getCount() == 0 || mListView == null) {
            return true;
        }

        return mListView.getFirstVisiblePosition() == 0 && mListView.getChildAt(0).getTop() == 0;
    }



    class UserAdapter extends ArrayAdapter<User> {
        private int mResourceId;

        public UserAdapter(Context context, int textViewResourceId) {
            super(context, textViewResourceId);
            this.mResourceId = textViewResourceId;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            User user = getItem(position);
            LayoutInflater inflater = getActivity().getLayoutInflater();
            View view = inflater.inflate(mResourceId, null);
            TextView nameText = (TextView) view.findViewById(R.id.name);
            TextView ageText = (TextView) view.findViewById(R.id.age);
            TextView sexText = (TextView) view.findViewById(R.id.sex);

            nameText.setText(user.getName());
            ageText.setText(user.getAge());
            sexText.setText(user.getSex());

            return view;
        }
    }

    class User {
        private int mAge;
        private String mName;
        private String mSex;

        public User(int age, String name, String sex) {
            this.mAge = age;
            this.mName = name;
            this.mSex = sex;
        }

        public String getName() {
            return this.mName;
        }

        public String getAge() {
            return this.mAge + "";
        }

        public String getSex() {
            return this.mSex;
        }
    }
}