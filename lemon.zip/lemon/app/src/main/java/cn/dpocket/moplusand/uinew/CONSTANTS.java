package cn.dpocket.moplusand.uinew;

/**
 * Created by Apple on 16/7/11.
 */
public class CONSTANTS {

    /**
     * 返回值类型
     */
    public static final int RESULT_SUCCESS  = 0;
    public static final int RESULT_FAIL = RESULT_SUCCESS + 1;
    public static final int RESULT_CANCEL = RESULT_FAIL + 1;


    /**
     * 微信ID
     */
    public static final String APPID_FOR_WEIXIN = "wxc81bc3d270e46d21";

    public static final String APPKEY_FOR_WEIBO = "4007297864";

    public static final String APPID_FOR_QQ = "100468855";


}
